import stomp, grpc
import time, sys, random
# import multiprocessing as mp -----------
import multiprocess as mp
import service_pb2
import service_pb2_grpc

class MyProcess (mp.Process):
    def __init__(self, port, conn, msg):
        super().__init__()
        self.port = port
        self.conn = conn
        self.msg = msg
    
    def run(self):


        channel = grpc.insecure_channel('127.0.0.1:'+str(self.port))
        stub = service_pb2_grpc.ServiceStub(channel)

        richiesta = str(self.msg).split('-')[0]
        print(self.msg, richiesta)

        if richiesta == 'deposita':
            result = stub.deposita(service_pb2.Item(id=int(self.msg.split('-')[1]), message = str(self.msg.split('-')[2])))
            # conn.send('/queue/request', str(result.message)) --------
            # lo hai fatto a tutti
            conn.send('/queue/response', str(result.message))

        elif richiesta == 'preleva':
            result = stub.preleva(service_pb2.Empty())
            # anche qui
            conn.send('/queue/response', str(result.id) + '-' + str(result.message))

        elif richiesta == 'svuota':
            for result in stub.svuota(service_pb2.Empty()):
                # e qui
                conn.send('/queue/response', str(result.id)+'-'+str(result.message))


class MyListener(stomp.ConnectionListener):
    def __init__(self, port, conn):
        self.port = port
        self.conn = conn
        
    def on_message(self, frame):
        p = MyProcess(self.port, self.conn, frame.body)
        p.start()



if __name__=="__main__":

    try:
        PORT = sys.argv[1]
    except IndexError:
        print('[DISPATCHER] specify a port')

    conn = stomp.Connection([('127.0.0.1',61613)])
    conn.set_listener('',MyListener(PORT, conn))
    conn.connect(wait=True)
    conn.subscribe('/queue/request', id = 1, ack='auto')

    print('[DISPATCHER] in ascolto')

    while True:
        time.sleep(60)
    
    conn.disconnect()