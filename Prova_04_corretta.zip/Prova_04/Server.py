import sys, time, grpc
import service_pb2
import service_pb2_grpc
from concurrent import futures
import multiprocessing as mp


class ServerImpl(service_pb2_grpc.ServiceServicer):

    def __init__(self, queue, lock_d, lock_p):
        self.queue = queue
        self.lock_d = lock_d
        self.lock_p = lock_p
    
    # def preleva(self): ----------------
    def preleva(self, request, ctx):
        with self.lock_p:
            result = self.queue.get()
        print("[SERVER] messaggio prelevato")
        return service_pb2.Item(id=result[0], message=result[1])

    def deposita (self, request, ctx):
        with self.lock_d:
            self.queue.put([request.id, request.message])

        print("[SERVER] messaggio depositato")

        return service_pb2.stringMessage(message='depositato')

    def svuota (self, request, ctx):

        self.lock_d.acquire()
        self.lock_p.acquire()

        while not self.queue.empty():
            result = self.queue.get()
            print('[SERVER] messaggio: ' + str(result[1]))

            yield service_pb2.Item(id=result[0], message=result[1])
            
        self.lock_d.release()
        self.lock_p.release()

if __name__=='__main__':

    q = mp.Queue(5)
    lock_d = mp.Lock()
    lock_p = mp.Lock()

    server = grpc.server(futures.ThreadPoolExecutor(max_workers=10),options=(('grpc.os_reuseport',0),))
    service_pb2_grpc.add_ServiceServicer_to_server(ServerImpl(q, lock_d, lock_p), server)

    port = 0

    port = server.add_insecure_port('[::]:'+str(port))

    print("[SERVER] In ascolto sul port: "+str(port))

    server.start()
    server.wait_for_termination()