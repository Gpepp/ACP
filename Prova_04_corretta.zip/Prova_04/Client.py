import stomp, random, time

class MyListner(stomp.ConnectionListener):

    def __init__(self, port):
        self.port = port

    def on_message(self, frame):
        
        print('[CLIENT] messaggio ricevuto: ' + frame.body)

if __name__=="__main__":

    conn = stomp.Connection([('127.0.0.1', 61613)])
    conn.set_listener('', MyListner(conn))
    conn.connect(wait=True)

    conn.subscribe('/queue/response', id=1, ack='auto')

    prodotto = ['laptop', 'tablet']

    for i in range(10):
        msg = 'deposita-'+str(random.randint(1,100))+'-'+prodotto[random.randint(0,1)]
        conn.send('/queue/request', msg)
    
    for i in range(5):
        msg = 'preleva'
        conn.send('/queue/request', msg)
    
    msg = 'svuota'
    conn.send('/queue/request', msg)


    while True:
        time.sleep(60)

    conn.disconnect()