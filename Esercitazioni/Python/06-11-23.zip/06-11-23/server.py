from implPrintServer import ImplPrintServer


if __name__ == "__main__":
    srv = ImplPrintServer()
    print("[Server] Start...")
    srv.run()

