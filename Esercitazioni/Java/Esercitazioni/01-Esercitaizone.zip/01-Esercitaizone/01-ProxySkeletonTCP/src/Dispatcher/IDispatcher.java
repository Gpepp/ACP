package Dispatcher;

public interface IDispatcher {
    public void sendCmd (int cmd);
    public int getCmd ();
}
